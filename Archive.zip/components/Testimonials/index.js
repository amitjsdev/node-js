import React from "react";
import styles from "./style.module.scss";
import SliderHome from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
// import SliderOne from "../assets/images/topBanner.jpg";
import SliderOne from "../../assets/images/topBanner.jpg";
import slider1 from "../../assets/images/sliderImages/slider1.jpeg";
import slider2 from "../../assets/images/sliderImages/slider2.jpeg";
import slider3 from "../../assets/images/sliderImages/slider3.jpeg";
import slider4 from "../../assets/images/sliderImages/slider4.jpeg";
import testimonialImg from "../../assets/images/testimonialBG.jpg";
import Image from "next/image";

const Slider = () => {
  const settings = {
    // dots: true,
    arrows: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
  };
  let sliderData = [
    { src: testimonialImg },
    { src: testimonialImg },
    { src: testimonialImg },
    { src: testimonialImg },
  ];

  return (
    <section>
      <div className={styles.Testimonialswrapper}>
        <div className={styles.testimonials}>
          <div className={styles.main}>
            <div className={styles.cardouter}>
              <div className={styles.cardwrapper}>
                <SliderHome {...settings}>
                  {sliderData.map((sliderObj, index) => {
                    return (
                      <div key={index} className={styles.backgroundSlide}>
                        <div className={styles.sliderContainer}>
                          <div className={styles.top}>
                            <h2>Testimonials</h2>
                            <p>
                              Our families, parents and children, can feel the
                              difference in the work we do every day. We are
                              grateful for their positive feedback.
                            </p>
                          </div>
                        </div>
                        <img
                          src={sliderObj.src}
                          alt="BackArrow"
                          className={styles.sliderBgImage}
                        />
                      </div>
                    );
                  })}

                  {/* <div className={styles.backgroundSlide}>
                <div className={styles.sliderContainer}>
                  <div className={styles.sliderContent}>
                    <h1>Virtual <br/>Tutoring, K-12</h1>
                    <p className={styles.middContent}>How does your child feel about his/her academic journey?</p>
                    <p>We care more about the effort put forth than the grades produced, and we inspire enthusiasm for learning in every session.</p>
                  </div>
                </div>
              </div>

              <div className={styles.backgroundSlide}>
                <div className={styles.sliderContainer}>
                  <div className={styles.sliderContent}>
                    <h1>Virtual <br/>Tutoring, K-12</h1>
                    <p className={styles.middContent}>How does your child feel about his/her academic journey?</p>
                    <p>We care more about the effort put forth than the grades produced, and we inspire enthusiasm for learning in every session.</p>
                  </div>
                </div>
              </div> */}
                </SliderHome>
              </div>
            </div>
            {/* <div className={styles.sliderarrow}>
              <div className={styles.leftarrow}>
                <img src={BackArrow} alt="BackArrow" />
              </div>
              <div className={styles.rightarrow}>
                <img src={FrontArrow} alt="FrontArrow" />
              </div>
            </div> */}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Slider;
