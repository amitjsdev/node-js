import dynamic from "next/dynamic";
import "./style.module.scss";
import React from "react";
const Slider = dynamic(() =>
  import("../index").then((mod) => mod.Slider)
);

const Header = dynamic(() =>
  import("../index").then((mod) => mod.Header)
);

const GlobalEducation = dynamic(() =>
  import("../index").then((mod) => mod.GlobalEducation)
);

const About = dynamic(() =>
  import("../index").then((mod) => mod.About)
);
const Services = dynamic(() => import("../index").then((mod) => mod.Services));

const Education = dynamic(() => import("../index").then((mod) => mod.Education));

const Testimonials = dynamic(() =>
  import("../index").then((mod) => mod.Testimonials)
);

const Contact = dynamic(() => import("../index").then((mod) => mod.Contact));

const Footer = dynamic(() => import("../index").then((mod) => mod.Footer));

const Layout = () => {
  const [scrolled, setScrolled] = React.useState(false);
  const handleScroll = () => {
     const scrollTop = window.pageYOffset || (document.documentElement || document.body.parentNode || document.body).scrollTop
    if(scrollTop <= 800){
      setScrolled(false)
    }
    if(scrollTop >= 800){
      setScrolled(true)
    }
  }
    React.useEffect(()=>{
    window.addEventListener("scroll", handleScroll, false)
      return function cleanup() {
        window.removeEventListener('scroll' , handleScroll)
    };
  },[])

console.log("scrolled",scrolled)

return(
  <div>
  <Header />
  <Slider />
  <GlobalEducation />
  <About />
  <Services />
  <Education />
  <Testimonials />
  <Contact/>
  <Footer/>
</div>
)
  
}

export default Layout;
