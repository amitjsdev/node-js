import React from "react";
import styles from "./style.module.scss";
import Hamburger from "../../assets/images/hamburger.png";
import Logo from "../../assets/images/Logo.png";

const Header = () => {
  const [scrolled, setScrolled] = React.useState(false);
  const handleScroll = () => {
     const scrollTop = window.pageYOffset || (document.documentElement || document.body.parentNode || document.body).scrollTop
    if(scrollTop <= 800){
      setScrolled(false)
    }
    if(scrollTop >= 800){
      setScrolled(true)
    }
  }
    React.useEffect(()=>{
    window.addEventListener("scroll", handleScroll, false)
      return function cleanup() {
        window.removeEventListener('scroll' , handleScroll)
    };
  },[])
  console.log("scrolled",scrolled)
    return (

    <div className={styles.headerwrapper}>
       <div className={styles.header}>
        <nav className={styles.navigation}>
          <a className={styles.navbarlogo} href="#">
            <img src={Logo} alt="Logo" />
          </a>
          <div>
            <button className="" type="button">
              <span className="">
                <img src={Hamburger} alt="Hamburger" />
              </span>
            </button>
            <div className={styles.navigationbar} id="">
              <ul className={styles.navi}>
                <li className={scrolled ? styles.navitem :  styles.navitem}>
                  <a className="navlink" href="#">
                    Home
                  </a>
                </li>
                <li className={scrolled ? styles.navitem :  styles.navitem}>
                  <a className={styles.navlink} href="#">
                    About
                  </a>
                </li>
                <li className={scrolled ? styles.navitem :  styles.navitem}>
                  <a className={styles.navlink} href="#">
                   Services
                  </a>
                </li>
                <li className={scrolled ? styles.navitem :  styles.navitem}>
                  <a className={styles.navlink} href="#">
                  Testimonials                   
                  </a>
                </li>
                <li className={scrolled ? styles.navitem :  styles.navitem}>
                  <a className={styles.navlink} href="#">
                  Contact                   
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </nav>
        </div>
   </div>

   
  
  );
};

export default Header;