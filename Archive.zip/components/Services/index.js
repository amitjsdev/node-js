import React from "react";
import styles from "./style.module.scss";
import Remediation from "../../assets/images/remediation.png";
import Enrichment from "../../assets/images/enrichment.png";
import Isee from "../../assets/images/Isee.png";

const Services = () => {
  return (
    <div className={styles.serviceswrapper}>
    <div className={styles.services}>
      <div className={styles.headingtop}>
        <h2>Our Services</h2>
        <p>
          All of our sessions are primarily offered online in a one-to-one or
          small group setting. There are some available options for in-person
          tutoring as well. Inquire to learn more
        </p>
      </div>
      <div className={styles.maincnt}>
        <div className={styles.flexrow}>
          {/* <div className={`${styles.flexcol} ${styles.flexcolmd4}`}> */}
            <div className={styles.servicescard}>
              <img src={Remediation} alt="Remediation" />
              <h3>REMEDIATION</h3>
              <p>
                Some students have fallen behind with their academic skills
                ranging from reading (decoding/ sight word recognition/ fluency)
                to comprehension, to math, to writing. An intensive, daily
                program is typically recommended to close those learning gaps.
                The tutors on our team are trained in the Lindamood-Bell and
                Step Up to Writing programs.
              </p>
            </div>
          {/* </div> */}
          {/* <div className={`${styles.flexcol} ${styles.flexcolmd4}`}> */}
            <div className={styles.servicescard}>
              <img src={Enrichment} alt="Enrichment" />
              <h3>ENRICHMENT</h3>
              <p>
                Some students may be struggling with isolated skills, such as
                executive functioning, spelling, and/or vocabulary. Or, an
                academic challenge is the best fit to propel these students even
                further. A less intensive boost of academic support is
                recommended in this case.
              </p>
            </div>
          {/* </div> */}
          {/* <div className={`${styles.flexcol} ${styles.flexcolmd4}`}> */}
            <div className={styles.servicescard}>
              <img src={Isee} alt="Isee" />
              <h3>ISEE TEST PREP</h3>
              <p>
                Some students are preparing to take the lower/middle/upper level
                ISEE. All five sections of this test are covered in this
                academic service. An introductory practice test is first
                conducted to assess how to get started. From there, a dynamic
                and individualized lesson plan is created to help the student
                achieve desired stanines.
              </p>
            </div>
          {/* </div> */}
        </div>
      </div>
    </div>
    </div>
  );
};

export default Services;
