// import React from "react";
// import styles from "./style.module.scss";

// const DigitalMarketing = () => {
//   return (
//     // <section className={styles.digitalMarketingWrapper}>
//     //   <div className={styles.digitalMarketingContent}>
//     //     <h1>
//     //       Digital Marketing <br />
//     //       and SEO <span>| Sacramento</span>
//     //     </h1>
//     //     <span className={styles.backText}>
//     //       <span>Digital Marketing</span>
//     //       <span>and SEO | Sacramento</span>
//     //     </span>

//     //     <p>
//     //       <b>Meta:</b> A website is critical today, but without accurate
//     //       Sacramento digital marketing and SEO solutions, you may still be
//     //       invisible. Architected Relations delivers crucial, industry-leading
//     //       solutions.
//     //     </p>
//     //   </div>
//     // </section>
//     <h1>
//        Digital Marketing <br />
//       and SEO <span>| Sacramento</span>
//      </h1>
//   );
// };

// export default DigitalMarketing;
