import React, { useState } from "react";
import styles from "./style.module.scss";
import { isPhoneNumber, isValidEmail } from '../../utils/index'
import axios from "axios"

const Contact = () => {
  const [errorMessagsObj, setErrorMessagesObj] = useState({})
  const [info, setInfo] = useState({})

  const onSubmitForm = async() => {
    let newObj = {}
    if (info) {
      if (!info.firstname || info.firstname === '') {
        newObj.firstName = "Please enter first name"
      }
      if (!info.lastname || info.lastname === '') {
        newObj.lastName = "Please enter last Name"
      }
      if (!info.email || info.email === '') {
        newObj.email = "Please enter email"
      }
      if (!info.message || info.message === '') {
        newObj.message = "Please enter message"
      }
      if (!info.phone || info.phone === '') {
        newObj.phone = "Please enter phone"
      }
      if (info.phone && !isPhoneNumber(info.phone)) {
        newObj.phone = "Please enter 10 digit phone number"
      }
      if (info.email && !isValidEmail(info.email)) {
        newObj.email = "Please enter valid email"
      }
    }
    if(Object.keys(newObj).length > 0){
      setErrorMessagesObj(newObj);
      return
    }else {
      axios({
        method: 'post',
        url: 'https://global-harris.herokuapp.com/',
        data: info
      }).then(response => response.json()).then(data => console.log("data",data)).catch(err =>{
        console.log("err",err)
      })
    }
    
   

  }

  const handleChange = (e, type) => {
    let infoObj = info;
    infoObj[type] = e.target.value;
    setInfo(infoObj)
  }

  const onSelectServices = (e, type) => {
    let infoObj = Object.assign({}, info);
    let services = []
    if (infoObj.services) {
      services = infoObj.services.slice()
      const index = services.findIndex((ele) => ele === type);
      if (index === -1) {
        services.push(type)
      } else {
        services.splice(index, 1)
      }
    } else {
      services.push(type)
    }
    infoObj.interested = services
    setInfo(infoObj)
  }
  return (
    <section>
      <div className={styles.Contactwrapper}>
        <h2>Contact Us</h2>
        <p>We’d love to hear more on how we can best assist your family.</p>
        <div className={styles.flexrow}>
          <div className={`${styles.flexcol12} ${styles.flexcolmd9}`}>
            <form className={styles.form1}>
              <div className={styles.formgroups}>
                <div className={styles.flexrow}>
                  <div className={styles.flexcol6}>
                    <label for="fst">First Name</label>
                    <input onChange={(e) => handleChange(e, "firstname")} type="text" id="fst" />
                    {errorMessagsObj.firstName && <p className = {styles.error}>{errorMessagsObj.firstName}</p>}
                  </div>
                  <div className={styles.flexcol6}>
                    <label for="lst">Last Name</label>
                    <input onChange={(e) => handleChange(e, "lastname")} type="text" id="lst" />
                    {errorMessagsObj.lastName && <p className = {styles.error}>{errorMessagsObj.lastName}</p>}
                  </div>
                </div>
              </div>
              {/* 2 */}
              <div className={styles.formgroups}>
                <div className={styles.flexrow}>
                  <div className={styles.flexcol6}>
                    <label for="mail">Email</label>
                    <input onChange={(e) => handleChange(e, "email")} type="email" id="mail" />
                    {errorMessagsObj.email && <p className = {styles.error}>{errorMessagsObj.email}</p>}

                  </div>
                  <div className={styles.flexcol6}>
                    <label for="phe">Phone</label>
                    <input onChange={(e) => handleChange(e, "phone")} type="text" id="phe" />
                    {errorMessagsObj.phone && <p className = {styles.error}>{errorMessagsObj.phone}</p>}

                  </div>
                </div>
              </div>
              <div className={styles.textarea}>
                <label for="msg">Message</label>
                <textarea onChange={(e)=>handleChange(e,'message')} rows="4" cols="50" id="msg"></textarea>
                {errorMessagsObj.message && <p className = {styles.error}>{errorMessagsObj.message}</p>}
              </div>

              <div className={styles.sendmsgbtn}>
                <button onClick={() => onSubmitForm()} type="button" className={styles.msgbtn}>
                  Send Message
                </button>
              </div>
            </form>
          </div>
          <div className={`${styles.flexcol12} ${styles.flexcolmd3}`}>
            <div className={styles.right}>
              <h4>Service(s) Interested In </h4>
              <form className={styles.form2}>
                <div className={styles.formgroups}>
                  <label className={styles.container}>
                    <input onChange={(e) => onSelectServices(e, 'Remediation')} type="checkbox" checked={info.services && info.services.includes('Remediation')} />
                    Remediation
                    <span className={styles.checkmark}></span>
                  </label>
                </div>
                <div className={styles.formgroups}>
                  <label className={styles.container}>
                    <input onChange={(e) => onSelectServices(e, 'Enrichment')} type="checkbox" checked={info.services && info.services.includes('Enrichment')} />
                    Enrichment
                    <span className={styles.checkmark}></span>
                  </label>
                </div>
                <div className={styles.formgroups}>
                  <label className={styles.container}>
                    <input onChange={(e) => onSelectServices(e, 'ISEE Prep')} type="checkbox" checked={info.services && info.services.includes('ISEE Prep')} />
                    ISEE Prep
                    <span className={styles.checkmark}></span>
                  </label>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;