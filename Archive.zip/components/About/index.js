import React from "react";
import styles from "./style.module.scss";
import Aboutkid from "../../assets/images/aboutUsKid.png";


const About = () => {
  return (
    <div className={styles.aboutwrapper}>
      <div className={styles.about}>
        <h2 className={styles.abouttitle}>About Us</h2>
        <div className={`${styles.flexrow} ${styles.aboutbg}`}>
          <div
            className={`${styles.leftcol} ${styles.flexcol12} ${styles.flexcollg7}`}
          >
            <div className={styles.aboutimg}>
              <img src={Aboutkid} alt="Aboutkid" />
            </div>
            <div className={styles.content}>
              <p className={styles.cnttop}>
                Mission: To inspire the love of learning inside and outside the
                classroom for students of all ages by reparing them to succeed
                academically, regardless of past struggles.
              </p>
              <p className={styles.cntbtm}>
                Hello, and welcome to Harris Global Education! We’re here to
                help families, students and parents, navigate the educational
                path from kindergarten to high school. We care about the
                wellbeing of our students, and ensure they are feeling proud and
                confident about the work they are producing every day.
                Regardless of whether a student has fallen behind, is on track,
                or is advanced with their academic skills - we are here for you.
              </p>
            </div>
          </div>

          <div className={`${styles.flexcol12} ${styles.flexcollg5}`}>
            <h2>Founder’s Message</h2>
            <p className={styles.rightcontent}>
              My passion for education started when my younger brother completed
              an intensive reading program. He was feeling defeated about his
              reading skills which impacted other areas of his early academic
              future. Luckily, he found the support he needed and made
              tremendous gains within a few months. I was absolutely amazed to
              see the positive boost in his confidence and overall happiness.
              From then on, I have devoted my work to teaching reading, and a
              variety of other subjects to students of all ages. I love those
              “ah-ha” moments when a student lights up because they understand a
              concept! I started Harris Global Education LLC in 2020 after 10+
              years of working in the education field as a teacher and manager
              of several national and international learning centers. My passion
              for education has only deepened, and I am thankful for the
              opportunities to support students to feel the way my brother felt
              after he received the professional support he needed.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
