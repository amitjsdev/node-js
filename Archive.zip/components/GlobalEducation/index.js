import React from "react";
import styles from "./style.module.scss";
import CoreValue from "../../assets/images/coreValues.png";
import FlexibleScheduling from "../../assets/images/flexibleScheduling.png";
import Result from "../../assets/images/results.png";

const GlobalEducation = () => {
  
  return (
    <section>
      <div className={styles.globaleducationwrapper}>
        <div className={styles.globaleducation}>
          <div className={styles.top}>
            <h2>Why Harris Global Education?</h2>
            <p>
              We recognize that a positive and growth-minded attitude towards
              learning is most important. We’re here to increase skills in a
              variety of subjects, while building confidence along the way.
            </p>
          </div>

          <div className={styles.flexrow}>
            <div className={styles.spaceadjust}>
              <div className={styles.center}>
                <div className={styles.corevalueimg}>
                  <img src={CoreValue} alt="corevalue" />
                </div>
                <h3>Core Values </h3>
                <p>Empathy, Fun, Growth, Creativity</p>
              </div>
            </div>
            <div className={styles.spaceadjust}>
              <div className={styles.center}>
                <div className={styles.corevalueimg}>
                  <img src={FlexibleScheduling} alt="FlexibleScheduling" />
                </div>
                <h3>Flexible Scheduling</h3>
                <p>
                  Our team is located across the U.S., and available{" "}
                  <b>Mon - Fri</b>
                </p>
              </div>
            </div>
            <div className={styles.spaceadjust}>
              <div className={styles.center}>
                <div className={styles.corevalueimg}>
                  <img src={Result} alt="Result" />
                </div>
                <h3>Results</h3>
                <p>
                  Our students can feel the difference after just a few sessions
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default GlobalEducation;