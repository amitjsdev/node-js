import React from "react";
import styles from "./style.module.scss";
import FooterLogo from "../../assets/images/footerLogo.png";
import Facebook from "../../assets/images/fb.png";
import Linkedin from "../../assets/images/linkedin.png";
import Twitter from "../../assets/images/twitter.png";
import Telegram from "../../assets/images/telegram.png";

const Footer = () => {
  return (
    <div className={styles.footerwrapper}>
      <div className={styles.footer}>
        <div className={styles.flexrow}>
          <div className={`${styles.flexcol12} ${styles.flexcolmd4}`}>
            <div className={styles.footerone}>
              <div className={styles.footerlogo}>
                <img src={FooterLogo} alt="logo" />
              </div>
              <p>
                We're here to help your child thrive inside and outside of the
                classroom. Every student is capable of academic success and
                booming confidence.{" "}
              </p>
            </div>
          </div>
          <div className={`${styles.flexcol12} ${styles.flexcolmd4}`}>
            <div className={styles.overview}>
              <h4>Overview</h4>
              <ul>
                <li>
                  <a href="#">Home</a>
                </li>
                <li>
                  <a href="#">About</a>
                </li>
                <li>
                  <a href="#">Services</a>
                </li>
                <li>
                  <a href="#">Testimonials</a>
                </li>
                <li>
                  <a href="#">Contact</a>
                </li>
              </ul>
              </div>
              <div className={styles.overviewmob}>
                <div className={styles.overviewone}>
                  <ul>
                    <li>
                      <a href="#">Home</a>
                    </li>
                    <li>
                      <a href="#">About</a>
                    </li>
                    <li>
                      <a href="#">Services</a>
                    </li>
                  </ul>
                </div>
                <div className={styles.overviewtwo}>
                  <ul>
                    <li>
                      <a href="#">Testimonials</a>
                    </li>
                    <li>
                      <a href="#">Contact</a>
                    </li>
                  </ul>
                </div>
              </div>
          </div>
          <div className={`${styles.flexcol12} ${styles.flexcolmd4}`}>
            <div className={styles.newsletter}>
              <h4>Newsletter</h4>
              <div className={styles.newslettermain}>
                <p>Newsletters are coming soon</p>
                <div className={styles.btnwrapper}>
                  <input type="email" placeholder="Enter your email address" />
                  <button type="button" className={styles.subscribebtn}>
                    Subscribe
                  </button>
                </div>
              </div>
              <div className={styles.socialicon}>
                <div className={styles.icon}>
                  <img src={Facebook} alt="facebook" />
                </div>
                <div className={styles.icon}>
                  <img src={Linkedin} alt="Linkedin" />
                </div>
                <div className={styles.icon}>
                  <img src={Twitter} alt="twitter" />
                </div>
                <div className={styles.icon}>
                  <img src={Telegram} alt="telegram" />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.pencil}>
          <p>Copyright © Harris Global Education LLC | All right reserved</p>
        </div>
      </div>
    </div>
  );
};

export default Footer;
