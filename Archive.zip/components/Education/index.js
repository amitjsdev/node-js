import React from "react";
import styles from "./style.module.scss";
// import Girl from "../../assets/images/girl.png";


const Education = () => {
  return (
    <div className={styles.educationwrapper}>
      <div className={styles.flexrow}>
        <div className={`${styles.flexcol} ${styles.flexcolmd6}`}>
          <div className={styles.leftimg}>
            {/* <img src={Girl} alt="Girl" /> */}
          </div>
        </div>
        <div className={`${styles.flexcol} ${styles.flexcolmd6}`}>
          <div className={styles.rightimg}>
            <h4 className={styles.desc}>
              The basic prerequisite for effective education is to cultivate a
              student’s enthusiasm for learning.
            </h4>
            <h4 className={styles.nme}>- Sir Ken Robinson</h4>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Education;
