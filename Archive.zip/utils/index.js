function isPhoneNumber(inputtxt) {
  let phoneno = /^\d{10}$/;
  if ((inputtxt.match(phoneno))){
    return true;
  }     
  else {
    return false;
  }
}

function isValidEmail(mail) 
{
 if (/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(mail))
  {
    return (true)
  }
    return (false)
}

module.exports.isPhoneNumber =isPhoneNumber;
module.exports.isValidEmail =isValidEmail
