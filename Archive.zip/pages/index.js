import React from "react";
import dynamic from "next/dynamic";
const Layout = dynamic(
  () => import("../components/index").then((mod) => mod.Layout)
  // import("../home/index").then((mod) => mod.Layout)
);
export default function Home() {
  return (
    <div>
      <Layout />
    </div>
  );
}
