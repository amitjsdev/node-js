var express = require("express");
var router = express.Router();
const sgMail = require("@sendgrid/mail");

const { check, validationResult } = require("express-validator");
require("dotenv").config();
/* GET home page. */
router.post(
  "/",
  [
    check("email", "Email must be valid ").isEmail(),
    check("firstname", "First name is required").exists(),
    check("phone")
      .notEmpty()
      .withMessage("Phone is required")
      .isLength({ min: 5 })
      .withMessage("Phone must be of length 10"),
    check("message", "Message fiels is required").notEmpty(),
    check("interseted").optional().isArray(),
  ],
  function (req, res, next) {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { firstname, lastname, phone, email, message, interested } = req.body;
    let interest = "";
    if (interested) {
      interested.forEach((val) => {
        interest += `<li>${val}</li>`;
      });
    }
    const msg = {
      to: "rchugh@innow8apps.com",
      from: email,
      subject: `Email received from ${email}`,
      html: `<strong>
                Harris global Query
            </strong>
            <div>
             <p> User name: ${firstname} ${lastname}</p>
             <p> Phone : ${phone}</p>
            </div>
            <div>
            <b>User Interest</b>
            <ul>
            ${interest}
            </ul>
            </div>
            <div>
              <h3>
                Message
              </h3>
              <p>
                ${message}
              <p>
            </div>
            `,
    };
    sgMail.setApiKey(
      "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"
    );
    sgMail
      .send(msg)
      .then(() => {
        //console.log('mail sent')
        // res.status(200).send('{ "status": "success"}');
        res.json({ status: "success" });
      })
      .catch((err) => {
        //console.log('mail Error: ', err);
        res
          .status(500)
          .send('{ "status" : "error", "errorMessag"”: "' + err + '"}');
      });
  }
);

module.exports = router;