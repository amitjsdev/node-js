
DROP PROCEDURE IF EXISTS `insertData`;
DELIMITER $$
CREATE PROCEDURE `insertData` (In Invalue1 varchar(50),In Invalue2 varchar(50),In Invalue3 varchar(50))
BEGIN
INSERT into table_name SET id = UUID_TO_BIN(uuid()),column1=Invalue1,column2=Invalue2,column3=Invalue3;
END $$
DELIMITER ;

DROP PROCEDURE IF EXISTS `spGetData`;
DELIMITER $$
CREATE PROCEDURE `spGetData` (In Inid varchar(50))
BEGIN
select * from table_name where id = UUID_TO_BIN(Inid);
END $$
DELIMITER ;