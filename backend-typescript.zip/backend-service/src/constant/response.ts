export const RESPONSES = {
  SUCCESS: 200,
  CREATED: 201,
  ACCEPTED: 202,
  NOCONTENT: 204,
  BADREQUEST: 400,
  FORBIDDEN: 403,
  NOTFOUND: 404,
  TIMEOUT: 408,
  CONFLICT:409,
  LENGTHREQUIRED:411,
  UNRESPONSIBLEENTITY:422,
  TOOMANYREQ: 429,
  INTERNALSERVER: 500,
  BADGATEWAYS: 502,
  SERVICEUNAVILABLE: 503,
  GATEWAYTIMEOUT: 504,
};

export const MIDDLEWARE_RESPONSE = {
  JWTERROR: "Unauthorize Request",
  WALLET_ZCH: process.env.WALLET_ZCH,
  WALLET_ETH: process.env.WALLET_ETH,
  TRADINGMAIN: process.env.TRADINGMAIN,
  WALLET_USD: process.env.WALLET_USD,
  PERMISSION_DENIED: "Permission has been denied for this user.",
};

export const RES_MSG = {
  ERROR: "Something went wrong",
  SUCCESS: "Get data successfully.",
  INVALID_STATUS: "Enter valid status",
  TOKEN_UPDATED:"Token updated successfully",

  REGISTER: {
    SUCCESS: "Your account has been created successfully.",
    UPDATED: "Information updated successfully",
    ALREADY_EXIST: "This account is already exist with us.",
    DELETED: "Account deleted successfully",
    EMAIL_EXIST: "Email already exist",
    LOGGED_IN: "You are logged in successfully.",
    LOGGED_OUT:"You are logged out successfully.",
    PHONE_NOT_EXIST: "Phone does not exist on our platform.",
    ACCOUNT_NOT_EXIST: "Account does not exist on our platform.",
    PHONE_EXIST: "Phone exist on our platform.",
  },
};
