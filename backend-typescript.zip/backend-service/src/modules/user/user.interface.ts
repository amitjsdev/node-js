export interface SIGNUP {
  email: string;
  password: String;
}
