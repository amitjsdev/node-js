import * as Interfaces from "@interfaces";
import * as UserInterface from "./user.interface";
import * as express from "express";
import { RES_MSG } from "../../constant/response";
import * as Helpers from "../../helpers";
import * as Middlewares from "../../middlewares/";
import { body, param } from "express-validator";
import model from "./user.model";

const setResponse = Helpers.ResponseHelper;
const utilities = Helpers.Utilities;
const mailHelper = Helpers.MailHelper;
const userHelper = Helpers.UserHelper.default;
const RedisHelper = Helpers.RedisHelper;
const RabbitMq = Helpers.RabbitMq;
const TwilioHelper = Helpers.TwilioHelper;

class UserController implements Interfaces.Controller {
  public path = "/user";
  public router = express.Router();
  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes() {
    this.router
      .all(`${this.path}/*`)
      .post(
        this.path + "/register",
        [
          body("email")
            .notEmpty()
            .withMessage("Email should not be empty.")
            .isEmail()
            .withMessage("Email address should be valid."),
          body("password")
            .notEmpty()
            .withMessage("Password should not be empty.")
            .isAlphanumeric()
            .withMessage("Password should be alphanumeric"),
        ],
        Middlewares.postValidate,
        this.registerUser
      );
  }

  private registerUser = async (
    request: express.Request,
    response: express.Response
  ) => {
    try {
      await model.startTransaction();
      /**
       * Your code comes here
       */
      const obj: UserInterface.SIGNUP = {
        email: request.body.email,
        password: request.body.password,
      };
      const result = await model.saveUser(obj);
      await model.commitTransaction();
      return setResponse.success(response, {
        message: RES_MSG.REGISTER.SUCCESS,
      });
    } catch (err) {
      await model.rollbackTransaction();
      return setResponse.error(response, {
        message: err,
      });
    }
  };
} // End of User Class
export default UserController;
