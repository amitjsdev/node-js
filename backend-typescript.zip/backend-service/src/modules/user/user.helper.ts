class UserHelper {
  constructor() {}
} // End of class

export default new UserHelper();
