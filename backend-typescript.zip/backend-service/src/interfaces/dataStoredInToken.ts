interface DataStoredInToken {
  _id: string;
}

export default DataStoredInToken;
