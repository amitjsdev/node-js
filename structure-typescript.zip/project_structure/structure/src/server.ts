import app from './app';

const port = process.env.PORT || 3000;

/***************************************************Server Running ****************************************************************/

app.listen(port, (): void => {
  console.log("App is Listening on port: " + port);
});
