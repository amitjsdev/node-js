import * as amqplib from "amqplib/callback_api";
import { Buffer } from "buffer";

class RabbitMq {
  public channel: any;
  constructor() {
    this.connections();
  }
  /*******************************************************Create Channel************************************************************/
  async connections() {
    amqplib.connect("amqp://guest:guest@localhost", (err, conn): any => {
      if (err) {
        throw err;
      } else {
        console.log("RabbitMQ Connection Established.");
      }
      conn.createChannel((error1, channel) => {
        if (error1) {
          throw error1;
        }
        this.channel = channel;
        channel.assertExchange("signup", "topic");
        channel.assertQueue("register", {
          durable: false,
        });
      });
    });
  }

  /*****************************************************Signup Queue****************************************************************/
  async createQueue(queue: string, data: any) {
    console.log("CREATE QUEUE WORKING HERE", queue, data);
   
    try {
      this.channel.sendToQueue(queue, Buffer.from(data));
    } catch (error) {
      console.log("rabbit create queue error is ", error);
    }
  }
  /****************************************************************Consume Signup Queue*********************************************/
  async consumeQueue(queue:string) {
    this.channel.bindQueue(queue, "signup", "users.*");
    this.channel.consume(queue, (data: any) => {
      console.log(data.content.toString());
      this.channel.ack(data);
    });
  }
}
export default new RabbitMq();
