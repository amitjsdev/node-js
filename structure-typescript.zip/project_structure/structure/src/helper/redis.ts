
import redis, { createClient, RedisClient } from 'redis';

class Redis {
  public client: any = RedisClient;
  private host: any = "127.0.0.1";
  private port: string = "6379";
  constructor() {
    this.client = createClient(this.port, this.host);
    this.client.on("connect", () => {
      console.log("Redis Connected");
    });
  }

  /**************************************************Set String Value for Given Key************************************************/
   async setString(
    key: string,
    value: string,
    expires: number = 0,
    database: string = ""
  ) {
    if (database !== "") {
      this.client.select(database);
    }
    return new Promise((resolve, reject) => {
      this.client.set(key, value, (err: any, reply: any) => {
        if (err) {
          return reject(err);
        }
        /****************************************************Add Expire Time if provided*******************************************/
        if (expires !== 0) {
          this.client.expire(key, expires * 60);
        }
        resolve(reply);
      });
    });
  }
  /********************************************************Get String value for given key******************************************/
  async getString(key: string, database: string = "") {
    if (database !== "") {
      this.client.select(database);
    }
    return new Promise((resolve, reject) => {
      this.client.get(key, (err: any, reply: any) => {
        if (err) {
          return reject(err);
        }
        resolve(reply);
      });
    });
  }
}
export default new Redis();