import {
  IsEmail,
  IsString,
  MaxLength,
  MinLength,
} from "class-validator";

class UserDto {
  @IsString()
  @MinLength(5, { message: "FirstName should be minimum of 5 characters" })
  public firstName?: string;

  @IsString()
  @MinLength(5, { message: "LastName should be minimum of 5 characters" })
  public lastName?: string;

  @IsEmail({}, { message: "Provided Email is not valid" })
  public email?: string;

  @IsString()
  @MinLength(8, { message: "Password should be minimum of 8 characters" })
  public password?: string;

  @IsString()
  @MinLength(10, { message: "PhoneNo should be minimum of 10 characters" })
  @MaxLength(10, { message: "PhoneNo should be minimum of 10 characters" })
  public phoneNo?: string;
}

export default UserDto;
