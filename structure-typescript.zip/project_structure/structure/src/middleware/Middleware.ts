import express from "express";

class UserMiddleware {
  /******************************************************* All Fields  *************************************************************/
  async validateRequiredUserBodyFields(
    req: express.Request,
    res: express.Response,
    next: express.NextFunction
  ) {
    if (req.body && req.body.email && req.body.password) {
      next();
    } else {
      res.status(400).send({
        error: `Missing required fields `,
      });
    }
  }
  /******************************************************Email Field ***********************************************************/
 async validationEmail(
    req: express.Request,
    res: express.Response,
    next: express.NextFunction
  ) {
    if (
      /^[\-0-9a-zA-Z\.\+_]+@[\-0-9a-zA-Z\.\+_]+\.[a-zA-Z]{2,}$/.test(
        String(req.body.email)
      )
    ) {
      next();
    } else {
      res.status(400).send("Email is not valid.");
    }
  }
  /****************************************************Phone No Field*************************************************************/
async validationPhoneNo(
    req: express.Request,
    res: express.Response,
    next: express.NextFunction
  ) {
    if (
      /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/.test(
        String(req.body.phoneNo)
      )
    ) {
      next();
    } else {
      res.status(400).send({
        error: ` PhoneNo  is invalid `,
      });
    }
  }
  /************************************************ Password Fields  *************************************************************/

  async validationPassword(
    req: express.Request,
    res: express.Response,
    next: express.NextFunction
  ) {
    if (
      /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{7,15}$/.test(
        String(req.body.password)
      )
    ) {
      next();
    } else {
      res.status(400).send({
        error: ` Password  is invalid `,
      });
    }
  }
}

export default UserMiddleware;
