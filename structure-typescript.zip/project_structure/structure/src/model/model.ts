import express, { Request, Response, NextFunction } from "express";
import { UserController } from "../controller/controller";
import UserMiddleware from "../middleware/Middleware";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import AuthToken from "../token/tokenverify";

export class Routes {
  public userController: UserController = new UserController();
  public userMiddleware: UserMiddleware = new UserMiddleware();
  public routes(app: express.Application): void {
    /***************************************************************Login***********************************************************/
    app.post("/login", this.userController.loginUser),
      /***************************************************************Signup********************************************************/
      app.post(
        "/signup",

        this.userMiddleware.validateRequiredUserBodyFields,
        this.userMiddleware.validationEmail,
        this.userMiddleware.validationPassword,
        this.userMiddleware.validationPhoneNo,
        this.userController.createUser
      ),
      /**********************************************************Token**************************************************************/
      app.post("/user", AuthToken.getToken, this.userController.user),
      /* ******************************************************Get Detail *********************************************************/
      app.get("/getallUser", this.userController.detail);
    /*********************************************************Google-Captcha********************************************************/
    app.post("/subscribe", this.userController.verfyCaptcha);
  }
}
