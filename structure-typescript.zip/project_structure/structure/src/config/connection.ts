import * as mysql from "mysql2";

export const mySqlConnection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "admin123",
  database: "typescript",
});
mySqlConnection.connect((err) => {
  if (err) {
    return console.error("error: " + err.message);
  }

  console.log("Connected to the DataBase.");
});
