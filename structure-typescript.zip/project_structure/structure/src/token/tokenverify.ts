import express ,{Request,Response,NextFunction}from 'express'
import jwt from 'jsonwebtoken'
const JWT_SECRET ='sjgd7689mncv';
 class AuthToken{
    static getToken(req: any,res:any,next:any){
        new Promise((resolve,reject)=>{
            const token =
            req.body.accessToken ||
            req.query.accessToken ||
            req.headers['api-access-token'];
          
                if (token == null) return res.sendStatus(401)
    
                jwt.verify(token, JWT_SECRET, (err: any,decoded:any) => {
                    if (decoded) {
                        req.userInfo = {
                            id:decoded.id,
                            email: decoded.email
                         };
                       next();
                    } else {
                       throw err
                    }
                 
    
        })
    })
    }   
    }
 export default  AuthToken;