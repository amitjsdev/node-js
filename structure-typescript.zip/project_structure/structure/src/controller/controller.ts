import { Request, Response, NextFunction } from "express";
import { mySqlConnection } from "../config/connection";
import rabbitmq from "../helper/rabbitmq";
import UserDto from "../dto/user.dto";
import redis from "../helper/redis";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import fetch from "node-fetch";
import { stringify } from "querystring";
const JWT_SECRET = "sjgd7689mncv";

export class UserController extends UserDto {
  /************************************************************** Create User ******************************************************/
  async createUser(req: Request, res: Response) {
    new Promise((resolve, reject) => {
      const user = {
        id: req.body.id,
        email: req.body.email,
        password: req.body.password,
        phoneNo: req.body.phoneNo,
        firstName: req.body.firstName,
        lastName: req.body.lastName,
      };

      mySqlConnection.query(
        "INSERT INTO users SET ?",
        user,
        (err, results, fileds) => {
          if (err) {
            reject({
              status: false,
              message: err.message,
            });
          } else {
            resolve({
              status: results,
              message: `User Registered Successfully `,
            });
            /************************************************Redis Set**************************************************************/
            redis.setString("register", JSON.stringify(user));
            /************************************************Redis Get**************************************************************/
            redis.getString("register");
            /*********************************************Rabbitmq CreateQueue******************************************************/
            rabbitmq.createQueue("register", JSON.stringify(user));

            /****************************************************Rabbitmq ConsumeQueue**********************************************/
            rabbitmq.consumeQueue("register");
          }
        }
      );
    })
      .then((successPayload) => {
        res.send(successPayload);
      })
      .catch((reason) => {
        res.send(reason);
      });
  }

  /**********************************************************Login User*************************************************************/
  async loginUser(req: Request, res: Response) {
    new Promise((resolve, reject) => {
      const user = {
        id: req.body.id,
        email: req.body.email,
        password: req.body.password,
        phoneNo: req.body.phoneNo,
        firstName: req.body.firstName,
        lastName: req.body.lastName,
      };
      const { email, password } = req.body;

      mySqlConnection.query(
        "SELECT * FROM users WHERE email = ?",
        [email],
        (err, results, fileds) => {
          if (!user) {
            return res.json({ status: "error", error: "Invalid email" });
          }

          if (bcrypt.compare(password, user.password)) {
            const token = jwt.sign(
              {
                id: user.id,
                email: user.email,
              },
              JWT_SECRET,
              {
                expiresIn: "1h",
              }
            );

            return res.json({ status: "Success", data: token });
          }

          res.json({ status: "error", error: "Invalid email" });
        }
      );
    });
  }

  /********************************************************Token Verifcation*******************************************************/

  async user(req: any, res: any) {
    try {
      console.log(req.userInfo);
    } catch (err) {
      throw err;
    }
  }
  /****************************************************Get Users Detail**********************************************************/
  async detail(req: any, res: any) {
    new Promise((resolve, reject) => {
      mySqlConnection.query("SELECT * FROM users ", (err, results, fileds) => {
        if (err) {
          reject({
            status: false,
            message: err.message,
          });
        } else {
          resolve({
            status: results,
          });
        }
      });
    })
      .then((successPayload) => {
        res.send(successPayload);
      })
      .catch((reason) => {
        res.send(reason);
      });
  }
  /***************************************************Google-Captcha****************************************************************/
  async verfyCaptcha(req: any, res: any) {
    // Secret key
    const secretKey = "6LfOHx8cAAAAAHCDilGwiQXEyHH0YUZmlCafjOjU";

    // Verify URL
    const query = stringify({
      secret: secretKey,
      response: req.body.captcha,
      remoteip: req.connection.remoteAddress,
    });
    const verifyURL = `https://google.com/recaptcha/api/siteverify?${query}`;
    // or
    /*   const verifyURL = `https://google.com/recaptcha/api/siteverify?secret=${secretKey&response=${req.body.captcha}&remoteip=${req.connection.remoteAddress}}`;*/

    // Make a request to verifyURL
    const body = await fetch(verifyURL).then((res) => res.json());

    // If not successful
    if (body.success !== undefined && !body.success)
      return res.json({ success: false, msg: "Failed captcha verification" });

    // If successful
    return res.json({ success: true, msg: "Captcha passed" });
  }
}
